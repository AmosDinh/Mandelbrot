#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main() {
   
    int max_iter = 20;
    const int res_h = 20000;

    float im_x1 = 0.32111;
    float im_x2 = 0.335;
    float re_x1 = 0.45111;
    float re_x2 = 0.465;
    
    const int res_w = res_h;// int(res_h * ( abs(abs(re_x2)-abs(re_x1)) / abs(abs(im_x2)-abs(im_x1)) ));
    
    //auto  img = new int[res_h][res_w];// value is k at y x: iterations to pass limit
    int *img = new int[res_h*res_w];
 


    int x = 0;
    int y = 0;

    float abs_h = im_x2-  im_x1 ;
    float abs_w= re_x2-  re_x1 ;
    float h_v = im_x1;
    float w_v = re_x1;
    cout<<"res_h"<<abs_h<<endl;
    for (float temp_im = 0;temp_im< res_h; temp_im++){
        
        x = 0;
        cout<<y<<endl;
        
        for (float temp_re = 0; temp_re<res_w; temp_re++){

            float im = (temp_im/res_h) * abs_h + h_v;
            
           

            float re = (temp_re/res_w) * abs_w + w_v;
            float re_1 = re;
            float im_1 = im;
            float z = 0;
            int k = 0;
            int wasset = 0;

            while (k < max_iter){
                float temp_re = re;
                re = re * re - im * im + re_1;
                im = 2 * temp_re * im + im_1 ;
                z = re * re + im * im; //# z hoch 2;

                k +=1;
                
                if (z>4){
                    //img[y][x] = k;
                    img[y*res_w+x] =k;
                    // cout<<img[y*res_w+x]<<endl;
                    wasset = 1;
                    // img.itemset((y,x,2), (k/max_iter)*255);
                    // img.itemset((y,x,1), (k/8)*255);
                    // img.itemset((y,x,0), (k/2)*200);
                    break;
                }

                    // #img[y][x] = [0,0,(k/max_iter)*255]


            }
            if (wasset == 0){
                 img[y*res_w+x] =0;
                 z = 0;
            }
                // #mit n = 0,1,2,3,... und x0=y0=0
              

    // #  img.itemset((y,x,2), (k/max_iter)*255)
    // #                 img.itemset((y,x,1), (k/8)*255)
    // #                 img.itemset((y,x,0), (k/2)*200)

                   

            x += 1;
        }
        y += 1;
    }
    ofstream outputfile("fs2.csv");
    for (int i = 0; i<res_h;i++){
        for (int j = 0; j<res_w-1;j++){
            outputfile <<to_string(img[i*res_w+j])<<",";
        }
        outputfile <<to_string(img[i*(res_w)+res_h-1])<<endl;
    }
    outputfile.close();

    return 0;
}
