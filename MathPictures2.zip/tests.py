
temporales_x = 1
for x in range(1,10):
    temporales_x = temporales_x * x
    print(temporales_x)