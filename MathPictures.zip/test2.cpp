#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main() {
   
    int max_iter = 20;
    const int res_h = 2500;

    //   double im_x1 = 0.33111;
    // double im_x2 = 0.335;
    // double re_x1 = 0.46111;
    // double re_x2 = 0.465;
    double im_x1 = 0.29111;
    double im_x2 = 0.425;
    double re_x1 = 0.40111;
    double re_x2 = 0.535;
    // double im_x1 = -1.5;
    // double im_x2 = 1.2;
    // double re_x1 = -1.3;
    // double re_x2 = 1;
 
    
    const int res_w = res_h;// int(res_h * ( abs(abs(re_x2)-abs(re_x1)) / abs(abs(im_x2)-abs(im_x1)) ));
    
    //auto  img = new int[res_h][res_w];// value is k at y x: iterations to pass limit
    
 


    int x = 0;
    int y = 0;

    double abs_h = im_x2-  im_x1 ;
    double abs_w= re_x2-  re_x1 ;
    double h_v = im_x1;
    double w_v = re_x1;
    cout<<"res_h"<<abs_h<<endl;

    ofstream outputfile("fstest.csv");

    for (double temp_im = 0;temp_im< res_h; temp_im++){
        
        x = 0;
        cout<<y<<endl;
        
        for (double temp_re1 = 0; temp_re1<res_w; temp_re1++){

            double im = (temp_im/res_h) * abs_h + h_v;
            
           

            double re = (temp_re1/res_w) * abs_w + w_v;
            double re_1 = re;
            double im_1 = im;
            double z = 0;
            int k = 0;
            int wasset = 0;

            while (k < max_iter){
                double temp_re2 = re;
                re = re * re - im * im + re_1;
                im = 2 * temp_re2 * im + im_1 ;
                z = re * re + im * im; //# z hoch 2;

                k +=1;
                
                if (z>4){
                    if (temp_re1 < res_w-1){
                         //img[y][x] = k;
                    //img[y*res_w+x] =k;
                    outputfile<<to_string(k)<<",";
                    // cout<<img[y*res_w+x]<<endl;
                    } else{
                        outputfile<<to_string(k)<<endl;
                    }
                    wasset = 1;
                   
                    // img.itemset((y,x,2), (k/max_iter)*255);
                    // img.itemset((y,x,1), (k/8)*255);
                    // img.itemset((y,x,0), (k/2)*200);
                    break;
                }

                    // #img[y][x] = [0,0,(k/max_iter)*255]


            }
            if (wasset == 0 ){

                if (temp_re1 < res_w-1){
                 outputfile <<to_string(0)<<",";

                }else{
                     outputfile <<to_string(0)<<endl;
                }
            }
                // #mit n = 0,1,2,3,... und x0=y0=0
              

    // #  img.itemset((y,x,2), (k/max_iter)*255)
    // #                 img.itemset((y,x,1), (k/8)*255)
    // #                 img.itemset((y,x,0), (k/2)*200)

                   

            x += 1;
        }
        y += 1;
    }
    outputfile.close();

    return 0;
}
