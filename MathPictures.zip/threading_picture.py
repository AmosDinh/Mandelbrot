import csv
import numpy as np
from PIL import Image

import threading

from pandas.core.arrays.sparse import dtype
img_temp = []
numrows = 0
with open('fstest.csv','r',newline='\n') as f:
    for i,row in enumerate(csv.reader(f,delimiter=',')):
        print(i)
        img_temp.append([row])
# img = np.zeros((len(img_temp[0]), len(img_temp), 3), dtype=np.uint8)
#print(img_temp[-1])
img = np.concatenate(img_temp, axis=0)

img = img.astype(np.uint8, copy=False)
# print(img)
# f = lambda k: np.array([0,0,(k/19)*255]).astype(np.uint8)
# func_app = np.frompyfunc(f,1,1)
# img =func_app(img)
r, g, b = img*0, img*0, (img/19)*255
img = np.dstack((r, g, b))
img = img.astype(np.uint8, copy=False)



# img[::2]
#print(np.concatenate(img_temp, axis=0)[-1])
# for x in range(0,len(img_temp)):
#     print(x)
#     for y in range(0,len(img_temp[0])):
#         k = int(img_temp[y][x])
#         #img[y][x] = [(k/2)*200,(k/8)*255,(k/20)*255]
#         img[y][x] = [0,0,(k/19)*255]
#         # img.itemset((y,x,2), (k/20)*255)
#         # img.itemset((y,x,1), (k/8)*255)
#         # img.itemset((y,x,0), (k/2)*200)

image = Image.fromarray(img,'RGB')
#d.reshape(-1)[25]
image=image.transpose(Image.FLIP_TOP_BOTTOM)
image.show()